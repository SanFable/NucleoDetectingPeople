#include "VL53L1X_I2C.h"
#include "VL53L1X_Class.h"
class Sensor {
public:
    Sensor(VL53L1X_DevI2C *device_i2c, DigitalOut &xshutdown, PinName interrupt){
    void print();

    }

private:
    VL53L1X_DevI2C *device_i2c = new VL53L1X_DevI2C(PA_10, PA_9); //SDA SCL
};