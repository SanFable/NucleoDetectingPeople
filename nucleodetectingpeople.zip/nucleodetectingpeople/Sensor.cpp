#include "Sensor.h"

Sensor::Sensor(VL53L1X_DevI2C *device_i2c, DigitalOut &xshutdown, PinName interrupt) : VL53L1X(device_i2c, &xshutdown, interrupt){
   
    VL53L1X(device_i2c, &xshutdown, interrupt);
    
    }


