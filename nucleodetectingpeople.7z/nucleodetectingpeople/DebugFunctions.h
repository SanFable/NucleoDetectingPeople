#include "mbed.h"

class DebugFunctions{
public:
DebugFunctions();
~DebugFunctions();
void checkaddrs();

};
 